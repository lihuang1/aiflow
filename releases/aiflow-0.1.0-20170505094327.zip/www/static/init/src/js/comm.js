/**
 * the common js of the project
 *
 * @author: xxxx
 * @version: 2016/10/27 10:51
 *           $Id$
 */
$(function () {

});