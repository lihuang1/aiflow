'use strict';
/**
 * config
 */
export default {
  //key: value
};