'use strict';
/**
 * config
 */
export default {
    //key: value
    port: 1234,
    sync_port: 3000,
    default_controller: "app",
    pro_conf_pref: 'aipro'
};
