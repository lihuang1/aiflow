'use strict';

export default {
  resource_on: false
};